#import "HBLinkTableCell.h"

@interface HBTwitterCell : HBLinkTableCell

@end
